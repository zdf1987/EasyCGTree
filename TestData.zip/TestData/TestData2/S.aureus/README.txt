Users can download the genomes' sequences directly from Batch Entrez (https://www.ncbi.nlm.nih.gov/sites/batchentrez). 
Upload the file "Assembly_number.txt",select "Assembly", and click "Retrieve".